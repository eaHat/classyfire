# Private functions for bootstrapping

.bootIndx <- function(data, indices) {
  return(indices) 
} 
